package org.lobobrowser.html.domimpl;

public class HTMLGenericMarkupElement extends HTMLAbstractUIElement {
	public HTMLGenericMarkupElement(String name) {
		super(name);
	}
}
